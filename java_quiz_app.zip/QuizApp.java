import java.util.*;

class Question {
    String question;
    String[] options;
    int answerIndex; // 0-based
    public Question(String q, String[] opts, int ans) {
        this.question = q;
        this.options = opts;
        this.answerIndex = ans;
    }
}

public class QuizApp {
    static Scanner sc = new Scanner(System.in);
    static Random rnd = new Random();
    static List<Question> questions = new ArrayList<>();
    static boolean usedFifty = false;

    public static void main(String[] args) {
        loadQuestions();
        System.out.println("==== Welcome to the Java Quiz App ====");
        System.out.println("Instructions: 10 questions, 4 options each. Type option number (1-4).");
        System.out.println("You have one 50-50 lifeline (type 50 to use). Good luck!\n");

        int score = 0;
        int qNo = 1;
        for (Question q : questions) {
            System.out.println(\"Q\" + qNo + \": \" + q.question);
            for (int i = 0; i < q.options.length; i++) {
                System.out.println(\"  \" + (i+1) + \") \" + q.options[i]);
            }

            int selection = -1;
            while (true) {
                System.out.print(\"Your answer (1-4 or 50 for 50-50): \");
                String in = sc.nextLine().trim();
                if (in.equals(\"50\")) {
                    if (!usedFifty) {
                        usedFifty = true;
                        applyFiftyFifty(q);
                        continue;
                    } else {
                        System.out.println(\"50-50 lifeline already used.\"); 
                        continue;
                    }
                }
                try {
                    selection = Integer.parseInt(in);
                    if (selection >= 1 && selection <= 4) break;
                } catch (Exception e) {}
                System.out.println(\"Invalid input. Please enter 1-4 or 50.\");
            }

            if (selection - 1 == q.answerIndex) {
                System.out.println(\"Correct! +10 points\\n\");
                score += 10;
            } else {
                System.out.println(\"Wrong. Correct answer: \" + (q.answerIndex + 1) + \") \" + q.options[q.answerIndex] + \"\\n\");
            }
            qNo++;
        }

        System.out.println(\"==== Quiz Finished ====\"); 
        System.out.println(\"Your score: \" + score + \" / \" + (questions.size()*10));
        if (score >= 80) System.out.println(\"Result: Excellent! Good job.\");
        else if (score >= 60) System.out.println(\"Result: Good. Keep practicing.\");
        else System.out.println(\"Result: Keep learning and try again.\"); 
        System.out.println(\"Thank you for playing the Java Quiz App.\"); 
    }

    static void applyFiftyFifty(Question q) {
        System.out.println(\"50-50 lifeline used: two wrong options removed.\");
        List<Integer> wrong = new ArrayList<>();
        for (int i = 0; i < q.options.length; i++) if (i != q.answerIndex) wrong.add(i);
        Collections.shuffle(wrong);
        // remove two wrong options by marking them as \"--\"\
        q.options[wrong.get(0)] = \"--\";
        q.options[wrong.get(1)] = \"--\";
        for (int i = 0; i < q.options.length; i++) {
            System.out.println(\"  \" + (i+1) + \") \" + q.options[i]);
        }
    }

    static void loadQuestions() {
        questions.add(new Question(\"Which keyword is used to create a subclass in Java?\", 
            new String[] {\"extends\", \"implements\", \"inherits\", \"subclass\"}, 0));
        questions.add(new Question(\"What is the size of int in Java (bits)?\", 
            new String[] {\"8\", \"16\", \"32\", \"64\"}, 2));
        questions.add(new Question(\"Which collection allows duplicate elements and preserves insertion order?\", 
            new String[] {\"HashSet\", \"ArrayList\", \"HashMap\", \"TreeSet\"}, 1));
        questions.add(new Question(\"Which keyword is used to handle exceptions in Java?\", 
            new String[] {\"catch\", \"throw\", \"try\", \"final\"}, 2));
        questions.add(new Question(\"Which method is the entry point of a Java program?\", 
            new String[] {\"start()\", \"main()\", \"run()\", \"init()\"}, 1));
        questions.add(new Question(\"Which of these is NOT a primitive type in Java?\", 
            new String[] {\"int\", \"String\", \"double\", \"char\"}, 1));
        questions.add(new Question(\"What does JDBC stand for?\", 
            new String[] {\"Java Database Connectivity\", \"Java Desktop Binding Connector\", \"Java Data Bridge\", \"None\"}, 0));
        questions.add(new Question(\"Which access modifier allows visibility within the same package?\", 
            new String[] {\"private\", \"public\", \"protected\", \"default (no modifier)\"}, 3));
        questions.add(new Question(\"What is the output of: System.out.println(2+\"\"+3); ?\", 
            new String[] {\"5\", \"23\", \"Compilation error\", \"Null\"}, 1));
        questions.add(new Question(\"Which loop is guaranteed to execute at least once?\", 
            new String[] {\"for\", \"while\", \"do-while\", \"foreach\"}, 2));
    }
}
