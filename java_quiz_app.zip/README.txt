
Java Quiz Application - QuizApp
--------------------------------

Description:
This is a simple console-based Java quiz application demonstrating:
- Java basics (classes, arrays, lists)
- OOP design (Question class)
- User input handling
- A 50-50 lifeline feature
- Scoring and result summary

Files included:
- QuizApp.java : Single-file Java program containing all code.
- README.txt  : This file (instructions + description).

How to compile and run (Linux / Windows / macOS):
1. Save QuizApp.java to a folder.
2. Open terminal / command prompt and navigate to the folder.
3. Compile:
   javac QuizApp.java
4. Run:
   java QuizApp
Notes:
- Requires JDK installed (javac and java commands available).
- This is your hands-on Java solution for Cognizant Superset. You can upload the .java file or a .zip containing the source file.
- If uploading a GitHub link is preferred, create a repo, add this file, and share the repo URL in Superset.
